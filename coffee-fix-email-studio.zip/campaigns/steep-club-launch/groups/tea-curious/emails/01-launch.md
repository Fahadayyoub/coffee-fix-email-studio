Subject: The Steep Club is open 🍵
Preview: You asked to hear first. The Steep Club is now open.

Hi {{first_name}},

You joined the waitlist to try something new with The Steep Club. It's now open, and you're one of the first to know.

The Steep Club is a monthly box of fresh, real tea. [TBC: who picks the tea, with one real detail, for example "tasted by our team in the shop". Delete this if we can't back it up.]

**What's in each box:** [TBC: which teas, how much, any extras]

**How it reaches you:** [TBC: delivery, pick-up in store or both]

**Price:** [TBC]

New to tea? You don't need to know anything to start. [TBC: if there is a brewing card, keep "Each box tells you how to make every tea in it." If not, delete this sentence.]

Thinking of someone else? The Steep Club can be a gift too. [TBC: gift option and the last order date for 25 December]

[TBC: waitlist welcome offer, if we have one. Delete this line if we don't.]

Take a moment and have a look. There's nothing to learn first.

[See The Steep Club](https://coffeefix.example/steep-club)

> Your coffee is waiting for your dull day. Just fix it.
> — Coffee Fix

You're getting this because you joined the Coffee Fix waitlist.
Coffee Fix, {{company_address}} · Unsubscribe: {{unsubscribe_url}}
