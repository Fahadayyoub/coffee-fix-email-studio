---
name: personalize
description: Write a version of each campaign email for every lead group in leads/leads.csv. Use when a campaign's emails are final and you want one copy per group.
argument-hint: "[campaign folder]"
context: fork
allowed-tools: Read, Glob, Grep, Write
---

# Personalize a campaign for each lead group

Campaign folder: $ARGUMENTS

## 1. Check the campaign folder

- If no campaign folder was given, **stop**. Use Glob on `campaigns/*/` to find the campaign folders. Reply with only this list and ask which one to use. Don't write any files.
- If the folder was given but has no `emails/` folder with `.md` files in it, stop and say so. Then list the campaign folders that do exist.

## 2. Read what you need

Read these first:

- `brand/voice.md`: the brand voice. Every version must follow it.
- `.claude/rules/emails.md`: the rules for every email file. Every version must follow them too.
- `leads/leads.csv`: use only the `group` column. Find each group that appears. Today these are `tea-curious`, `gift-buyers` and `daily-drinkers`. If the file lists more or fewer groups, use what the file says.
- Every `.md` file in `<campaign folder>/emails/`.

Never copy a lead's name, email address or any other personal detail into an email. Keep `{{first_name}}` as the greeting.

## 3. Write one version per email per group

For each group, think about who they are:

- **tea-curious:** they're new to tea or keen to try it. They want it to feel easy, with nothing to learn first.
- **gift-buyers:** they're buying for someone else. They care about how it arrives and how it feels to give.
- **daily-drinkers:** they come to Coffee Fix often. They want their usual fix and something new to enjoy alongside it.

For a group not listed here, work out who they are from the group name only. If that isn't clear, keep the email as it is and point this out in your summary.

In each version, change **only two things**:

1. **The opening line**, the first sentence after the greeting. Rewrite it to speak to that group.
2. **One example**: one sentence or short line in the body. Swap it for one that fits that group better.

Keep everything else exactly the same as the original:

- the `Subject:` and `Preview:` lines
- the greeting, the order of sections and the headings
- the one main link, including its button text and address
- every `[TBC: ...]` note. Don't fill these in or delete them.
- the sign-off and the two-line footer, copied exactly as plain text

When you rewrite a line:

- Don't add any new facts, such as prices, dates, offers, delivery details or claims about the tea. If the original says `[TBC]`, the new line can't fill it in.
- Follow the brand voice. No health claims, no "best" claims, no cheap or pushy words, and at most one emoji in a line.
- Use short sentences and everyday words.

## 4. Save the files

Save each version to `<campaign folder>/groups/<group>/emails/` with the same file name as the original. For example, `campaigns/steep-club-launch/emails/01-launch.md` becomes `campaigns/steep-club-launch/groups/gift-buyers/emails/01-launch.md`.

- Never change the original files in `<campaign folder>/emails/`.
- If a version file already exists, don't overwrite it. Skip that file and list it in your summary, because overwriting counts as deleting and the owner wants to be asked first.
- Never send, schedule or queue any email. Only write files.

## 5. Reply with a short summary only

When you're done, reply with only:

- how many files you wrote, and how many you skipped (if any)
- one example opening line for each group, like this:
  - **tea-curious:** "..."
  - **gift-buyers:** "..."
  - **daily-drinkers:** "..."
- one line for anything that needs the owner, such as a skipped file or an unclear group

Don't paste the full emails.
