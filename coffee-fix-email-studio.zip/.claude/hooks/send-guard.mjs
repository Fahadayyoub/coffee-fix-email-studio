// PreToolUse guard for the Resend MCP tools.
// Reads the tool call as JSON from standard input.
// Exit 0 allows the call. Exit 2 blocks it, and the reason on stderr is shown to Claude.

const ADDRESS_TOOLS = new Set(["send-email", "send-batch-emails"]);
const LIST_TOOLS = new Set([
  "send-broadcast",
  "create-automation",
  "send-inbox-draft",
  "send-new-inbox-email",
  "reply-to-inbox-thread-email",
  "forward-inbox-thread-email",
]);

function block(reason) {
  process.stderr.write(`Blocked by send-guard: ${reason}\n`);
  process.exit(2);
}

// Read all of standard input.
let raw = "";
for await (const chunk of process.stdin) raw += chunk;

let call;
try {
  call = JSON.parse(raw);
} catch {
  block("could not read the tool call, so it was stopped to be safe.");
}

// "mcp__resend__send-email" -> "send-email"
const fullName = String(call?.tool_name ?? "");
const tool = fullName.split("__").pop();
const input = call?.tool_input ?? {};

if (LIST_TOOLS.has(tool)) {
  block(`${tool} can reach real people or whole lists, so it is never allowed here.`);
}

if (!ADDRESS_TOOLS.has(tool)) {
  process.exit(0);
}

const myEmail = (process.env.MY_EMAIL ?? "").trim().toLowerCase();

// Turn a field (string, array, or missing) into a list of bare addresses.
// "Name <a@b.com>" becomes "a@b.com".
function addresses(field) {
  if (field == null) return [];
  const list = Array.isArray(field) ? field : [field];
  return list.map((item) => {
    const text = String(item).trim();
    const inBrackets = text.match(/<([^>]+)>/);
    return (inBrackets ? inBrackets[1] : text).trim();
  });
}

function isAllowed(address) {
  const a = address.toLowerCase();
  if (a.endsWith("@resend.dev")) return true;
  if (myEmail && a === myEmail) return true;
  return false;
}

const emails = tool === "send-batch-emails" ? input.emails : [input];
if (!Array.isArray(emails) || emails.length === 0) {
  block(`${tool} had no emails to check, so it was stopped to be safe.`);
}

for (const email of emails) {
  for (const field of ["to", "cc", "bcc"]) {
    for (const address of addresses(email?.[field])) {
      if (!isAllowed(address)) {
        block(
          `"${address}" in ${field} is not allowed. ` +
            `Only addresses ending in @resend.dev or your own email can be used.`
        );
      }
    }
  }
}

process.exit(0);
