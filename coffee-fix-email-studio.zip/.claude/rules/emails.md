---
paths:
  - "campaigns/**/emails/*.md"
---

# Rules for every email file

These rules apply to every email file in any campaign's `emails/` folder, and only to those files. Every email must follow all of them.

## 1. Subject and preview come first

- The very first line is `Subject: ...`. The subject text must be **50 characters or fewer**.
- The second line is `Preview: ...`. The preview text must be **90 characters or fewer**.
- Count the characters. Don't guess.

## 2. Greet the reader by name

Greet the reader with `{{first_name}}`, for example: `Hi {{first_name}},`

Never write a real or made-up name in its place.

## 3. Exactly one main link

Each email has one main link, and only one. Write it like this, changing only the button text:

[Button text](https://coffeefix.example/steep-club)

Don't add a second main link or point it anywhere else.

## 4. End with the sign-off, then the footer

Every email ends with our sign-off from `brand/voice.md`:

> Your coffee is waiting for your dull day. Just fix it.
> — Coffee Fix

Right after the sign-off, add this two-line footer. Copy it exactly, as plain text. Don't put it inside a code block or a quote.

You're getting this because you joined the Coffee Fix waitlist.
Coffee Fix, {{company_address}} · Unsubscribe: {{unsubscribe_url}}

Nothing comes after the footer.
